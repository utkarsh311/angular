import { Component, OnInit } from '@angular/core';
import {Reminder} from '../remnder'
@Component({
  selector: 'app-reminder',
  templateUrl: './reminder.component.html',
  styleUrls: ['./reminder.component.css']
})
export class ReminderComponent implements OnInit {
/* reminder=Reminder;
rem:Reminder;
 */
/* reminder.reminderName:'abc'; */
   reminder:Reminder={
  reminderName:'',
  reminderDescription:''
}; 
savedreminder=Reminder;
/* name=''; */
  constructor() {
  }
  onClick (rem:Reminder)
{
/*    
  this.savedreminder.reminderName=rem.reminderName;
  this.savedreminder.reminderDescription=rem.reminderDescription; 
 */
}

ngOnInit() {
  }

}
