import { Component, OnInit } from '@angular/core';
import {Category} from '../category';
@Component({
  selector: 'app-category',
  templateUrl: './category.component.html',
  styleUrls: ['./category.component.css']
})
export class CategoryComponent implements OnInit {
savedcategory=Category;
category:Category={
  categoryName:'',
  categoryDescription:''
};
onClick (cat:Category)
{
   
   this.savedcategory.categoryName=cat.categoryName; 
   this.savedcategory.categoryDescription=cat.categoryDescription;  
}

constructor() { 
 }


  ngOnInit() {
  }

} 
