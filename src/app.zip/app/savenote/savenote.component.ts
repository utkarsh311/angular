import { Component, OnInit } from '@angular/core';
import {Note} from '../note';
@Component({
  selector: 'app-savenote',
  templateUrl: './savenote.component.html',
  styleUrls: ['./savenote.component.css']
})
export class SavenoteComponent implements OnInit {
  panelOpenState = false;
  savednote=Note; 
  note:Note={
    noteName:'',
    noteTitle:'',
    noteDescription:''
  }; 
  submit(note:Note)
  {
   /*  this.savednote.noteName=note.noteName;
    this.savednote.noteTitle=note.noteTitle;
    this.savednote.noteDescription=note.noteDescription; */ 
  }
  
  constructor() { }

  ngOnInit() {
  }

}
