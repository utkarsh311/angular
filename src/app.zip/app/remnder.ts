export class Reminder
{
    reminderName:String;
    reminderDescription:String;
}