export class Note
{
    noteName:String;
    noteTitle:String;
    noteDescription:String;
}