export class Category
{
    categoryName:String;
    categoryDescription:String;
}